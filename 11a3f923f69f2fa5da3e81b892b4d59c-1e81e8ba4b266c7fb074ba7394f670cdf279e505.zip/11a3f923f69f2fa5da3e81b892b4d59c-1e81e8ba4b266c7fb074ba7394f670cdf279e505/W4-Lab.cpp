//
// Created by erika on 2/9/2026.
//

#include <iostream>
#include <string>

using namespace std;

int main() {
    string fullname;
    int month, day;
    string zodiac = "";

    cout << "Enter your full name: ";
    getline(cin, fullname);

    cout << "Enter your birth month (1-12): ";
    cin >> month;

    cout << "Enter your birth day: ";
    cin >> day;

    if ((month == 3 && day >= 21) || (month == 4 && day <= 19)) {
        zodiac = "Aries";
    } else if ((month == 4 && day >= 20) || (month == 5 && day <=20)) {
        zodiac = "Taurus";
    } else if ((month == 5 && day >= 21) || (month == 6 && day <= 20)) {
        zodiac = "Gemini";
    } else if ((month == 6 && day >= 21) || (month == 7 && day <= 20)) {
        zodiac = "Cancer";
    } else if ((month == 7 && day>= 23) || (month == 8 && day <= 22)) {
        zodiac = "Leo";
    } else if ((month == 10 && day >= 23) || (month == 11 && day <= 21)) {
        zodiac = "Scorpio";
    } else if ((month == 11 && day >= 22) || (month == 12 && day <= 21)) {
        zodiac = "Sagittarius";
    } else if ((month == 12 && day >= 22) || (month == 1 && day <= 19)) {
        zodiac = "Capricorn";
    } else if ((month == 1 && day >= 20) || (month == 2 && day <= 18)) {
        zodiac = "Aquarius";
    } else if ((month == 2 && day >= 19) || (month == 3 && day <= 20)) {
        zodiac = "Pisces";
    } else {
        zodiac = "Unknown ( Invalid Date)";
    }

    cout << "Hello " << fullname <<" Your zodiac sign is: " << zodiac << endl;

    return 0;
}